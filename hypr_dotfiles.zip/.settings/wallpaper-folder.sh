# Enter the path to the folder that includes your wallpapers
wallpaper_folder=$HOME/wallpaper