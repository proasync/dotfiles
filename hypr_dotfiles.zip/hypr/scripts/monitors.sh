#!/bin/bash
hyprctl -j monitors