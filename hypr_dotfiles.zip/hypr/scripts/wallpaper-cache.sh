#!/bin/bash
generated_versions="$HOME/.cache/ml4w-wallpaper-generated"
rm $HOME/.cache/ml4w-wallpaper-generated/*
echo ":: Wallpaper cache cleared"
notify-send "Wallpaper cache cleared"